

EECS 839 PROJECT
DODDALA MAHITHA
KU ID :2787070
**********************************************************

README FILE:
1)Unzip the program contents and save them in a folder.
2)Copy the input file you wish to check the rules in the same folder created in step 1.
3)Build the source code using the command �ant �f  build.xml�
4)Run the command �java �jar EECS839_MAHITHA.jar�
5)Give the input file, alpha value so that you can see the Output file generated in the same folder.  
